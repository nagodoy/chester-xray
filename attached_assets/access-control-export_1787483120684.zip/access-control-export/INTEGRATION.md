# Guia de integração

## 1. Banco

Execute `sql/001_access_control.sql` usando o mecanismo de migrações do
projeto. Se o projeto já possui uma classe declarativa SQLAlchemy, copie os
modelos para o mesmo `Base` ou adapte `Base` no módulo backend.

## 2. Dependência de usuário autenticado

O host precisa conectar a sessão existente ao pacote. Exemplo:

```python
from fastapi import Depends, HTTPException, Request

def get_current_user_email(request: Request) -> str:
    email = getattr(request.state, "user_email", None)
    if not email:
        raise HTTPException(status_code=401, detail="Authentication required")
    return email
```

O middleware que preenche `request.state.user_email` deve validar o token,
expiração, logout e qualquer OTP antes de chegar nessa função.

## 3. Rotas

```python
from fastapi import FastAPI
from access_control import create_access_control_router

app = FastAPI()
app.include_router(
    create_access_control_router(
        get_db=get_db,
        get_current_user_email=get_current_user_email,
    )
)
```

As rotas incluídas são:

```text
/api/allowed-emails
/api/allowed-domains
/api/access-control-audit
/api/allowed-emails/env-admins
```

## 4. Bootstrap de admins de ambiente

Depois de abrir uma sessão SQLAlchemy na inicialização:

```python
from access_control import bootstrap_env_admins

bootstrap_env_admins(db)
```

O bootstrap é idempotente. Ele cria ou promove as linhas que aparecem em
`ADMIN_USERS`/`ADMIN_EMAILS`, mas a variável continua vencendo a tabela até
ser removida com o procedimento de migração definido pelo projeto.

## 5. Frontend

Use os helpers de `frontend/access-control.ts` com o objeto retornado pela
validação da sessão:

```ts
const nextPath = firstAccessiblePath(session.allowed_pages, session.is_admin);
const items = visibleNavSlugs(session.allowed_pages, session.is_admin);
```

O frontend deve ocultar navegação, mas nunca substituir as verificações de
backend.

## 6. Adaptadores obrigatórios

- autenticação e sessão;
- envio de código/OTP, se usado;
- lista de páginas;
- traduções e componentes visuais;
- conexão/migração de banco;
- logging e observabilidade.

## 7. Testes mínimos

Teste no projeto consumidor:

- sessão ausente recebe `401`;
- usuário autenticado sem admin recebe `403` em CRUD;
- e-mail individual ativo autoriza;
- domínio ativo autoriza;
- e-mail individual vence domínio para papel/páginas;
- admin de ambiente sempre é admin;
- admin de ambiente não pode ser alterado/apagado por CRUD;
- último admin não pode ser removido;
- cada alteração grava auditoria;
- lista vazia ou desconhecida não cria uma restrição ambígua.
