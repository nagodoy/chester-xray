-- Portable PostgreSQL schema. Adapt UUID types/defaults to the host project
-- if it already has a shared identifier strategy.

CREATE TABLE IF NOT EXISTS allowed_email (
  id VARCHAR(36) PRIMARY KEY,
  email VARCHAR(320) NOT NULL UNIQUE,
  label TEXT NULL,
  role VARCHAR(64) NOT NULL DEFAULT 'technician',
  allowed_pages TEXT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS allowed_domain (
  id VARCHAR(36) PRIMARY KEY,
  domain VARCHAR(255) NOT NULL UNIQUE,
  label TEXT NULL,
  role VARCHAR(64) NOT NULL DEFAULT 'technician',
  allowed_pages TEXT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS access_control_audit_log (
  id VARCHAR(36) PRIMARY KEY,
  actor_email VARCHAR(320) NOT NULL,
  actor_role VARCHAR(64) NULL,
  action VARCHAR(64) NOT NULL,
  target_email VARCHAR(320) NULL,
  target_role VARCHAR(64) NULL,
  detail_json JSONB NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_allowed_email_email ON allowed_email (email);
CREATE INDEX IF NOT EXISTS ix_allowed_domain_domain ON allowed_domain (domain);
CREATE INDEX IF NOT EXISTS ix_access_audit_actor ON access_control_audit_log (actor_email);
CREATE INDEX IF NOT EXISTS ix_access_audit_created ON access_control_audit_log (created_at);
