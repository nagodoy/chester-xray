# Access Control Export

Pacote portátil de controle de acesso para aplicações FastAPI + SQLAlchemy +
React/TypeScript.

## O que está incluído

- `backend/access_control.py`: modelos SQLAlchemy, normalização, resolução de
  papel/páginas, bootstrap e factory de rotas administrativas.
- `frontend/access-control.ts`: tipos e helpers para navegação e proteção de
  páginas.
- `sql/001_access_control.sql`: definição SQL inicial para PostgreSQL.
- `tests/test_access_control.py`: testes do núcleo de autorização.
- `INTEGRATION.md`: passos de integração e limites do pacote.

## Limite intencional

O pacote não envia OTP, não escolhe provedor de e-mail e não cria sessões.
Esses detalhes variam entre projetos. O consumidor deve fornecer a dependency
`get_current_user_email`, que retorna o e-mail já autenticado. O e-mail não
deve ser extraído de query string ou body para fins de autorização.

## Instalação mínima

```bash
pip install fastapi pydantic sqlalchemy
```

Copie `backend/access_control.py`, registre o router e aplique a migração.
Veja `INTEGRATION.md` para o exemplo completo.

## Configuração

```text
ADMIN_USERS=admin@example.org,owner@example.org
```

`ADMIN_EMAILS` é aceito como nome legado se `ADMIN_USERS` estiver vazio.
Substitua a lista de slugs em `backend/access_control.py` pelos slugs do
projeto consumidor.

## Exportação

O diretório é autocontido e não contém credenciais, dados de produção,
endereços institucionais ou dependências do sistema MR Joelho QC.
