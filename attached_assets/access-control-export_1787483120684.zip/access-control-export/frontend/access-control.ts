/** Portable page-level access helpers.
 *
 * The backend remains authoritative. These functions only control navigation
 * visibility and the fallback route after a forbidden page is requested.
 */

export type AllowedPages = string[] | null;

export interface SessionAccess {
  email: string;
  is_admin: boolean;
  role: string;
  allowed_pages: AllowedPages;
}

export const DEFAULT_PAGE_SLUGS = [
  "analyses",
  "upload",
  "kpi",
  "audit",
  "settings",
  "ia-admin",
  "network-logs",
  "about",
  "process-model",
] as const;

export const ADMIN_ONLY_SLUGS = new Set<string>([
  "ia-admin",
  "network-logs",
  "process-model",
]);

export function canAccess(allowedPages: AllowedPages, slug: string): boolean {
  return allowedPages === null || allowedPages.includes(slug);
}

export function visibleNavSlugs(
  allowedPages: AllowedPages,
  isAdmin: boolean,
  pageSlugs: readonly string[] = DEFAULT_PAGE_SLUGS,
): string[] {
  return pageSlugs.filter(
    (slug) =>
      (!ADMIN_ONLY_SLUGS.has(slug) || isAdmin) &&
      canAccess(allowedPages, slug),
  );
}

export function firstAccessiblePath(
  allowedPages: AllowedPages,
  isAdmin: boolean,
  pageToPath: (slug: string) => string = (slug) =>
    slug === "analyses" ? "/" : `/${slug}`,
  pageSlugs: readonly string[] = DEFAULT_PAGE_SLUGS,
): string {
  const first = pageSlugs.find(
    (slug) =>
      (!ADMIN_ONLY_SLUGS.has(slug) || isAdmin) &&
      canAccess(allowedPages, slug),
  );
  return first ? pageToPath(first) : "/";
}

export function isForbiddenPage(
  access: SessionAccess,
  slug: string,
): boolean {
  return (
    !canAccess(access.allowed_pages, slug) ||
    (ADMIN_ONLY_SLUGS.has(slug) && !access.is_admin)
  );
}
