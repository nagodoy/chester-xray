import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from access_control import (
    AccessControlAuditLog,
    AccessResolver,
    AllowedDomain,
    AllowedEmail,
    Base,
    bootstrap_env_admins,
    normalize_domain,
    normalize_email,
    normalize_pages,
)


def make_db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return Session(engine)


def test_normalizers_are_canonical():
    assert normalize_email("  User@Example.ORG ") == "user@example.org"
    assert normalize_domain("@Example.ORG") == "example.org"
    assert normalize_pages(["analyses", "unknown"]) == ["analyses"]
    assert normalize_pages([]) is None


def test_email_wins_over_domain_and_admin_gets_all_pages(monkeypatch):
    db = make_db()
    db.add(AllowedDomain(domain="example.org", role="radiologist", allowed_pages=json.dumps(["kpi"])))
    db.add(AllowedEmail(email="person@example.org", role="technician", allowed_pages=json.dumps(["upload"])))
    db.commit()

    resolver = AccessResolver(db)
    assert resolver.role("PERSON@example.org") == "technician"
    assert resolver.allowed_pages("person@example.org") == ["upload"]

    monkeypatch.setenv("ADMIN_USERS", "root@example.org")
    admin = AccessResolver(db)
    assert admin.is_admin("ROOT@example.org")
    assert admin.allowed_pages("root@example.org") is None


def test_env_bootstrap_is_idempotent_and_audited(monkeypatch):
    db = make_db()
    monkeypatch.setenv("ADMIN_USERS", "new@example.org")

    assert bootstrap_env_admins(db) == 1
    assert bootstrap_env_admins(db) == 0
    row = db.query(AllowedEmail).one()
    assert row.role == "admin" and row.is_active
    assert db.query(AccessControlAuditLog).count() == 1
