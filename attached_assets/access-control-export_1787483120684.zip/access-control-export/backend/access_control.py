"""Portable access-control core for FastAPI + SQLAlchemy applications.

Authentication is intentionally injected by the host application. This module
owns authorization, access-control CRUD, page restrictions, env-admin
bootstrap, and audit records.
"""
from __future__ import annotations

import csv
import io
import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Iterable, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, field_validator
from sqlalchemy import Boolean, Column, DateTime, JSON, String, Text
from sqlalchemy.orm import DeclarativeBase, Session


class Base(DeclarativeBase):
    pass


def _id() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


VALID_ROLES = (
    "technician",
    "radiologist",
    "admin",
    "consultor",
    "validador_tecnico",
    "validador_radiologista",
)

DEFAULT_PAGE_SLUGS = (
    "analyses",
    "upload",
    "kpi",
    "audit",
    "settings",
    "ia-admin",
    "network-logs",
    "about",
    "process-model",
)


class AllowedEmail(Base):
    __tablename__ = "allowed_email"

    id = Column(String, primary_key=True, default=_id)
    email = Column(String, unique=True, index=True, nullable=False)
    label = Column(String, nullable=True)
    role = Column(String, nullable=False, default="technician")
    allowed_pages = Column(Text, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=_now, nullable=False)


class AllowedDomain(Base):
    __tablename__ = "allowed_domain"

    id = Column(String, primary_key=True, default=_id)
    domain = Column(String, unique=True, index=True, nullable=False)
    label = Column(String, nullable=True)
    role = Column(String, nullable=False, default="technician")
    allowed_pages = Column(Text, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=_now, nullable=False)


class AccessControlAuditLog(Base):
    __tablename__ = "access_control_audit_log"

    id = Column(String, primary_key=True, default=_id)
    actor_email = Column(String, index=True, nullable=False)
    actor_role = Column(String, nullable=True)
    action = Column(String, index=True, nullable=False)
    target_email = Column(String, index=True, nullable=True)
    target_role = Column(String, nullable=True)
    detail_json = Column(JSON, nullable=True)
    created_at = Column(DateTime, index=True, default=_now, nullable=False)


def normalize_email(value: str) -> str:
    return (value or "").strip().lower()


def normalize_domain(value: str) -> str:
    return (value or "").strip().lower().lstrip("@")


def env_admin_emails(
    environ: Optional[dict[str, str]] = None,
    names: tuple[str, ...] = ("ADMIN_USERS", "ADMIN_EMAILS"),
) -> set[str]:
    source = os.environ if environ is None else environ
    raw = source.get(names[0]) or source.get(names[1], "")
    return {normalize_email(item) for item in raw.split(",") if normalize_email(item)}


def normalize_pages(
    pages: Optional[Iterable[str]],
    page_slugs: Iterable[str] = DEFAULT_PAGE_SLUGS,
) -> Optional[list[str]]:
    if pages is None:
        return None
    known = set(page_slugs)
    result = [str(page) for page in pages if str(page) in known]
    return result or None


def parse_pages(
    raw: Optional[str],
    page_slugs: Iterable[str] = DEFAULT_PAGE_SLUGS,
) -> Optional[list[str]]:
    if not raw:
        return None
    try:
        value = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    return normalize_pages(value, page_slugs) if isinstance(value, list) else None


def serialize_pages(
    pages: Optional[Iterable[str]],
    page_slugs: Iterable[str] = DEFAULT_PAGE_SLUGS,
) -> Optional[str]:
    value = normalize_pages(pages, page_slugs)
    return json.dumps(value) if value is not None else None


class AccessEntry(BaseModel):
    label: Optional[str] = None
    is_active: bool = True
    role: str = "technician"
    allowed_pages: Optional[list[str]] = None

    @field_validator("role")
    @classmethod
    def valid_role(cls, value: str) -> str:
        if value not in VALID_ROLES:
            raise ValueError(f"role must be one of: {', '.join(VALID_ROLES)}")
        return value


class EmailCreate(AccessEntry):
    email: str


class EmailUpdate(BaseModel):
    label: Optional[str] = None
    is_active: Optional[bool] = None
    role: Optional[str] = None
    allowed_pages: Optional[list[str]] = None

    @field_validator("role")
    @classmethod
    def valid_role(cls, value: Optional[str]) -> Optional[str]:
        if value is not None and value not in VALID_ROLES:
            raise ValueError(f"role must be one of: {', '.join(VALID_ROLES)}")
        return value


class DomainCreate(AccessEntry):
    domain: str


class DomainUpdate(EmailUpdate):
    pass


def _entry_dict(row: Any, is_domain: bool = False) -> dict[str, Any]:
    key = "domain" if is_domain else "email"
    return {
        "id": row.id,
        key: getattr(row, key),
        "label": row.label,
        "role": row.role,
        "is_active": row.is_active,
        "allowed_pages": parse_pages(row.allowed_pages),
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }


def _audit(
    db: Session,
    actor: str,
    action: str,
    target: Optional[str],
    target_role: Optional[str],
    detail: Optional[dict[str, Any]] = None,
) -> None:
    db.add(
        AccessControlAuditLog(
            actor_email=normalize_email(actor),
            actor_role="admin",
            action=action,
            target_email=target,
            target_role=target_role,
            detail_json=detail,
        )
    )
    db.flush()


def bootstrap_env_admins(
    db: Session,
    environ: Optional[dict[str, str]] = None,
) -> int:
    """Create/promote env admins idempotently and record the changes."""
    changed = 0
    for email in sorted(env_admin_emails(environ)):
        row = db.query(AllowedEmail).filter(AllowedEmail.email == email).first()
        if row is None:
            db.add(
                AllowedEmail(
                    email=email,
                    label="Environment-defined administrator",
                    role="admin",
                    is_active=True,
                )
            )
            _audit(db, "system:env-bootstrap", "email_added", email, "admin")
            changed += 1
        elif row.role != "admin" or not row.is_active:
            before = {"role": row.role, "is_active": row.is_active}
            row.role = "admin"
            row.is_active = True
            _audit(
                db,
                "system:env-bootstrap",
                "email_updated",
                email,
                "admin",
                {"from": before, "source": "environment"},
            )
            changed += 1
    if changed:
        db.commit()
    return changed


class AccessResolver:
    """Resolve admin status, role and page access for an authenticated email."""

    def __init__(
        self,
        db: Session,
        page_slugs: Iterable[str] = DEFAULT_PAGE_SLUGS,
        environ: Optional[dict[str, str]] = None,
    ):
        self.db = db
        self.page_slugs = tuple(page_slugs)
        self.env_admins = env_admin_emails(environ)

    def is_admin(self, email: str) -> bool:
        normalized = normalize_email(email)
        if normalized in self.env_admins:
            return True
        row = (
            self.db.query(AllowedEmail)
            .filter(
                AllowedEmail.email == normalized,
                AllowedEmail.role == "admin",
                AllowedEmail.is_active.is_(True),
            )
            .first()
        )
        return row is not None

    def role(self, email: str) -> str:
        normalized = normalize_email(email)
        if normalized in self.env_admins:
            return "admin"
        row = (
            self.db.query(AllowedEmail)
            .filter(AllowedEmail.email == normalized, AllowedEmail.is_active.is_(True))
            .first()
        )
        if row and row.role in VALID_ROLES:
            return row.role
        domain = normalize_domain(normalized.split("@", 1)[-1]) if "@" in normalized else ""
        row = (
            self.db.query(AllowedDomain)
            .filter(AllowedDomain.domain == domain, AllowedDomain.is_active.is_(True))
            .first()
        )
        return row.role if row and row.role in VALID_ROLES else "technician"

    def allowed_pages(self, email: str) -> Optional[list[str]]:
        normalized = normalize_email(email)
        if normalized in self.env_admins or self.is_admin(normalized):
            return None
        row = (
            self.db.query(AllowedEmail)
            .filter(AllowedEmail.email == normalized, AllowedEmail.is_active.is_(True))
            .first()
        )
        if row:
            return parse_pages(row.allowed_pages, self.page_slugs)
        domain = normalize_domain(normalized.split("@", 1)[-1]) if "@" in normalized else ""
        row = (
            self.db.query(AllowedDomain)
            .filter(AllowedDomain.domain == domain, AllowedDomain.is_active.is_(True))
            .first()
        )
        return parse_pages(row.allowed_pages, self.page_slugs) if row else None

    def is_allowed_to_login(self, email: str) -> bool:
        normalized = normalize_email(email)
        if normalized in self.env_admins:
            return True
        if (
            self.db.query(AllowedEmail)
            .filter(AllowedEmail.email == normalized, AllowedEmail.is_active.is_(True))
            .first()
        ):
            return True
        domain = normalize_domain(normalized.split("@", 1)[-1]) if "@" in normalized else ""
        return bool(
            domain
            and self.db.query(AllowedDomain)
            .filter(AllowedDomain.domain == domain, AllowedDomain.is_active.is_(True))
            .first()
        )


def _admin_guard(
    db: Session,
    email: str,
    environ: Optional[dict[str, str]] = None,
) -> str:
    if not AccessResolver(db, environ=environ).is_admin(email):
        raise HTTPException(status_code=403, detail="Admin access required")
    return normalize_email(email)


def create_access_control_router(
    get_db: Callable[..., Any],
    get_current_user_email: Callable[..., Any],
    *,
    prefix: str = "/api",
    page_slugs: Iterable[str] = DEFAULT_PAGE_SLUGS,
    environ: Optional[dict[str, str]] = None,
) -> APIRouter:
    """Create routes while leaving authentication and DB lifecycle to the host."""
    router = APIRouter(tags=["access-control"])
    pages = tuple(page_slugs)

    def admin_email(
        db: Session = Depends(get_db),
        email: str = Depends(get_current_user_email),
    ) -> str:
        return _admin_guard(db, email, environ)

    def output_email(row: AllowedEmail) -> dict[str, Any]:
        return _entry_dict(row)

    @router.get(f"{prefix}/allowed-emails")
    def list_emails(db: Session = Depends(get_db), _: str = Depends(admin_email)):
        return [output_email(r) for r in db.query(AllowedEmail).order_by(AllowedEmail.email).all()]

    @router.get(f"{prefix}/allowed-emails/env-admins")
    def list_env_admins(_: str = Depends(admin_email)):
        return {"emails": sorted(env_admin_emails(environ))}

    @router.get(f"{prefix}/allowed-emails/export/csv")
    def export_emails(db: Session = Depends(get_db), _: str = Depends(admin_email)):
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(["email", "label", "role", "is_active", "created_at"])
        for row in db.query(AllowedEmail).order_by(AllowedEmail.email).all():
            writer.writerow([row.email, row.label or "", row.role, int(row.is_active), row.created_at or ""])
        return StreamingResponse(
            iter([buffer.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=allowed_emails.csv"},
        )

    @router.post(f"{prefix}/allowed-emails", status_code=201)
    def create_email(
        body: EmailCreate,
        db: Session = Depends(get_db),
        actor: str = Depends(admin_email),
    ):
        email = normalize_email(body.email)
        if "@" not in email:
            raise HTTPException(400, "Invalid email address")
        if db.query(AllowedEmail).filter(AllowedEmail.email == email).first():
            raise HTTPException(409, "Email already exists")
        row = AllowedEmail(
            email=email,
            label=body.label or None,
            role=body.role,
            is_active=body.is_active,
            allowed_pages=serialize_pages(body.allowed_pages, pages),
        )
        db.add(row)
        _audit(db, actor, "email_added", email, body.role, {"label": body.label})
        db.commit()
        db.refresh(row)
        return output_email(row)

    @router.patch(f"{prefix}/allowed-emails/{{entry_id}}")
    def update_email(
        entry_id: str,
        body: EmailUpdate,
        db: Session = Depends(get_db),
        actor: str = Depends(admin_email),
    ):
        row = db.query(AllowedEmail).filter(AllowedEmail.id == entry_id).first()
        if not row:
            raise HTTPException(404, "Email not found")
        if normalize_email(row.email) in env_admin_emails(environ):
            raise HTTPException(409, "Environment-defined administrators are read-only")
        if normalize_email(row.email) == actor and (
            body.is_active is False or body.role not in (None, "admin")
        ):
            raise HTTPException(409, "You cannot demote or deactivate your own account")
        if row.role == "admin" and row.is_active and (
            body.is_active is False or body.role not in (None, "admin")
        ):
            count = db.query(AllowedEmail).filter(
                AllowedEmail.role == "admin", AllowedEmail.is_active.is_(True)
            ).count()
            if count <= 1:
                raise HTTPException(409, "Cannot remove the last active admin account")
        changes: dict[str, Any] = {}
        if body.label is not None:
            changes["label"] = {"from": row.label, "to": body.label or None}
            row.label = body.label or None
        if body.is_active is not None:
            changes["is_active"] = {"from": row.is_active, "to": body.is_active}
            row.is_active = body.is_active
        if body.role is not None:
            changes["role"] = {"from": row.role, "to": body.role}
            row.role = body.role
        if "allowed_pages" in body.model_fields_set:
            row.allowed_pages = serialize_pages(body.allowed_pages, pages)
            changes["allowed_pages"] = body.allowed_pages
        _audit(db, actor, "email_updated", row.email, row.role, changes)
        db.commit()
        db.refresh(row)
        return output_email(row)

    @router.delete(f"{prefix}/allowed-emails/{{entry_id}}")
    def delete_email(
        entry_id: str,
        db: Session = Depends(get_db),
        actor: str = Depends(admin_email),
    ):
        row = db.query(AllowedEmail).filter(AllowedEmail.id == entry_id).first()
        if not row:
            raise HTTPException(404, "Email not found")
        if normalize_email(row.email) in env_admin_emails(environ):
            raise HTTPException(409, "Environment-defined administrators are read-only")
        if normalize_email(row.email) == actor:
            raise HTTPException(409, "You cannot delete your own account")
        if row.role == "admin" and row.is_active:
            count = db.query(AllowedEmail).filter(
                AllowedEmail.role == "admin", AllowedEmail.is_active.is_(True)
            ).count()
            if count <= 1:
                raise HTTPException(409, "Cannot remove the last active admin account")
        target = row.email
        role = row.role
        db.delete(row)
        _audit(db, actor, "email_deleted", target, role)
        db.commit()
        return {"ok": True}

    @router.get(f"{prefix}/allowed-domains")
    def list_domains(db: Session = Depends(get_db), _: str = Depends(admin_email)):
        return [_entry_dict(r, True) for r in db.query(AllowedDomain).order_by(AllowedDomain.domain).all()]

    @router.post(f"{prefix}/allowed-domains", status_code=201)
    def create_domain(
        body: DomainCreate,
        db: Session = Depends(get_db),
        actor: str = Depends(admin_email),
    ):
        domain = normalize_domain(body.domain)
        if not domain or "." not in domain:
            raise HTTPException(400, "Invalid domain")
        if db.query(AllowedDomain).filter(AllowedDomain.domain == domain).first():
            raise HTTPException(409, "Domain already exists")
        row = AllowedDomain(
            domain=domain,
            label=body.label or None,
            role=body.role,
            is_active=body.is_active,
            allowed_pages=serialize_pages(body.allowed_pages, pages),
        )
        db.add(row)
        _audit(db, actor, "domain_added", domain, body.role, {"label": body.label})
        db.commit()
        db.refresh(row)
        return _entry_dict(row, True)

    @router.patch(f"{prefix}/allowed-domains/{{entry_id}}")
    def update_domain(
        entry_id: str,
        body: DomainUpdate,
        db: Session = Depends(get_db),
        actor: str = Depends(admin_email),
    ):
        row = db.query(AllowedDomain).filter(AllowedDomain.id == entry_id).first()
        if not row:
            raise HTTPException(404, "Domain not found")
        if body.label is not None:
            row.label = body.label or None
        if body.is_active is not None:
            row.is_active = body.is_active
        if body.role is not None:
            row.role = body.role
        if "allowed_pages" in body.model_fields_set:
            row.allowed_pages = serialize_pages(body.allowed_pages, pages)
        _audit(db, actor, "domain_updated", row.domain, row.role)
        db.commit()
        db.refresh(row)
        return _entry_dict(row, True)

    @router.delete(f"{prefix}/allowed-domains/{{entry_id}}")
    def delete_domain(
        entry_id: str,
        db: Session = Depends(get_db),
        actor: str = Depends(admin_email),
    ):
        row = db.query(AllowedDomain).filter(AllowedDomain.id == entry_id).first()
        if not row:
            raise HTTPException(404, "Domain not found")
        target = row.domain
        role = row.role
        db.delete(row)
        _audit(db, actor, "domain_deleted", target, role)
        db.commit()
        return {"ok": True}

    @router.get(f"{prefix}/access-control-audit")
    def audit(
        offset: int = 0,
        limit: int = 50,
        actor: Optional[str] = Query(None),
        db: Session = Depends(get_db),
        _: str = Depends(admin_email),
    ):
        query = db.query(AccessControlAuditLog).order_by(AccessControlAuditLog.created_at.desc())
        if actor:
            query = query.filter(AccessControlAuditLog.actor_email.ilike(f"%{actor}%"))
        rows = query.offset(max(0, offset)).limit(min(max(1, limit), 200)).all()
        return {
            "total": query.count(),
            "entries": [
                {
                    "id": row.id,
                    "actor_email": row.actor_email,
                    "actor_role": row.actor_role,
                    "action": row.action,
                    "target_email": row.target_email,
                    "target_role": row.target_role,
                    "detail_json": row.detail_json,
                    "created_at": row.created_at.isoformat() if row.created_at else None,
                }
                for row in rows
            ],
        }

    return router
